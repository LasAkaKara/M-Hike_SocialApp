package com.example.mhike.ui.discovery;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.mhike.R;
import com.example.mhike.database.entities.Hike;
import com.example.mhike.ui.adapters.FeedHikeAdapter;
import com.example.mhike.ui.viewmodels.SearchFeedViewModel;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.progressindicator.CircularProgressIndicator;
import com.google.android.material.textview.MaterialTextView;

/**
 * FeedFragment - Display public hikes from followed users
 * Shows a real-time feed of activities from people you follow
 */
public class FeedFragment extends Fragment {
    
    private SearchFeedViewModel viewModel;
    private FeedHikeAdapter feedAdapter;
    private RecyclerView recyclerView;
    private SwipeRefreshLayout swipeRefresh;
    private CircularProgressIndicator progressIndicator;
    private MaterialTextView emptyStateText;
    
    public FeedFragment() {
        // Required empty public constructor
    }
    
    public static FeedFragment newInstance() {
        return new FeedFragment();
    }
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_feed, container, false);
    }
    
    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        
        viewModel = new ViewModelProvider(this).get(SearchFeedViewModel.class);
        
        // Initialize UI components
        recyclerView = view.findViewById(R.id.feedRecyclerView);
        swipeRefresh = view.findViewById(R.id.swipeRefresh);
        progressIndicator = view.findViewById(R.id.progressIndicator);
        emptyStateText = view.findViewById(R.id.emptyStateText);
        
        // Setup RecyclerView
        feedAdapter = new FeedHikeAdapter(getContext(), new FeedHikeAdapter.OnHikeClickListener() {
            @Override
            public void onHikeClick(Hike hike) {
                // TODO: Navigate to hike details
                showSnackbar("Opening hike: " + hike.name);
            }
            
            @Override
            public void onAuthorClick(Hike hike) {
                // TODO: Navigate to user profile
                showSnackbar("View profile of " + hike.userName);
            }
        });
        
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(feedAdapter);
        
        // Setup SwipeRefresh
        swipeRefresh.setOnRefreshListener(() -> {
            viewModel.loadFeed();
        });
        
        // Observe LiveData
        viewModel.getFeedHikes().observe(getViewLifecycleOwner(), hikes -> {
            if (hikes != null && !hikes.isEmpty()) {
                feedAdapter.setHikes(hikes);
                recyclerView.setVisibility(View.VISIBLE);
                emptyStateText.setVisibility(View.GONE);
            } else {
                recyclerView.setVisibility(View.GONE);
                emptyStateText.setVisibility(View.VISIBLE);
                emptyStateText.setText("No hikes in your feed. Start following users!");
            }
        });
        
        viewModel.getIsFeedLoading().observe(getViewLifecycleOwner(), isLoading -> {
            progressIndicator.setVisibility(isLoading ? View.VISIBLE : View.GONE);
            swipeRefresh.setRefreshing(isLoading);
        });
        
        viewModel.getFeedErrorMessage().observe(getViewLifecycleOwner(), errorMessage -> {
            if (errorMessage != null) {
                showSnackbar(errorMessage);
            }
        });
        
        // Load feed on creation
        viewModel.loadFeed();
    }
    
    /**
     * Show snackbar message
     */
    private void showSnackbar(String message) {
        if (getView() != null) {
            Snackbar.make(getView(), message, Snackbar.LENGTH_SHORT).show();
        }
    }
}
