package com.example.mhike.database.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * User entity - Represents a user in the application
 * Used for displaying user profiles, search results, and follower information
 */
@Entity(tableName = "users")
public class User {
    @PrimaryKey
    public long id;
    
    public String username;
    public String avatarUrl;
    public String bio;
    public String region;
    
    public int followerCount = 0;
    public int followingCount = 0;
    public int hikeCount = 0;
    public double totalDistance = 0;
    
    public long createdAt;
    public long updatedAt;
    
    public User() {
    }
    
    public User(long id, String username, String avatarUrl, String bio, String region) {
        this.id = id;
        this.username = username;
        this.avatarUrl = avatarUrl;
        this.bio = bio;
        this.region = region;
        this.createdAt = System.currentTimeMillis();
        this.updatedAt = System.currentTimeMillis();
    }
    
    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", followerCount=" + followerCount +
                ", followingCount=" + followingCount +
                ", hikeCount=" + hikeCount +
                '}';
    }
}
