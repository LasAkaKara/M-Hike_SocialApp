package com.example.mhike.services;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.example.mhike.database.entities.Hike;
import com.example.mhike.database.entities.User;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * FeedService - Handles all API calls for feed, search, and follow functionality
 * Provides methods for:
 * - Searching users by name
 * - Following/unfollowing users
 * - Retrieving feed (followed users' public hikes)
 * - Checking follow status
 */
public class FeedService {
    
    private static final String TAG = "FeedService";
    private static final String PREFS_NAME = "m_hike_auth";
    private static final String TOKEN_KEY = "jwt_token";
    
    private static final String BASE_URL = "https://kandis-nonappealable-flatly.ngrok-free.dev/api";
    
    private final Context context;
    private final SharedPreferences prefs;
    private final OkHttpClient httpClient;
    private final Gson gson;
    private String authToken;
    
    // Callback interfaces
    public interface UserSearchCallback {
        void onSuccess(List<User> users);
        void onError(String errorMessage);
    }
    
    public interface FeedCallback {
        void onSuccess(List<Hike> hikes);
        void onError(String errorMessage);
    }
    
    public interface FollowCallback {
        void onSuccess(String message);
        void onError(String errorMessage);
    }
    
    public interface CheckFollowCallback {
        void onSuccess(boolean isFollowing);
        void onError(String errorMessage);
    }
    
    public FeedService(Context context, OkHttpClient httpClient) {
        this.context = context.getApplicationContext();
        this.httpClient = httpClient;
        this.prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        this.gson = new Gson();
        this.authToken = prefs.getString(TOKEN_KEY, null);
    }
    
    /**
     * Search users by username
     */
    public void searchUsers(String username, int limit, int offset, UserSearchCallback callback) {
        String url = BASE_URL + "/search/users?username=" + username + "&limit=" + limit + "&offset=" + offset;
        
        Request request = new Request.Builder()
            .url(url)
            .get()
            .build();
        
        httpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e(TAG, "Search users failed: " + e.getMessage());
                if (callback != null) {
                    callback.onError("Network error: " + e.getMessage());
                }
            }
            
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                try {
                    if (response.isSuccessful() && response.body() != null) {
                        String responseBody = response.body().string();
                        JsonArray jsonArray = gson.fromJson(responseBody, JsonArray.class);
                        
                        List<User> users = new ArrayList<>();
                        for (int i = 0; i < jsonArray.size(); i++) {
                            JsonObject jsonObject = jsonArray.get(i).getAsJsonObject();
                            User user = gson.fromJson(jsonObject, User.class);
                            users.add(user);
                        }
                        
                        if (callback != null) {
                            callback.onSuccess(users);
                        }
                    } else {
                        if (callback != null) {
                            callback.onError("Failed to search users: " + response.code());
                        }
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Error parsing search results: " + e.getMessage());
                    if (callback != null) {
                        callback.onError("Error parsing results: " + e.getMessage());
                    }
                }
            }
        });
    }
    
    /**
     * Get feed - all public hikes from followed users
     */
    public void getFeed(long userId, int limit, int offset, FeedCallback callback) {
        String url = BASE_URL + "/hikes/user/" + userId + "/following?limit=" + limit + "&offset=" + offset;
        
        Request request = new Request.Builder()
            .url(url)
            .get()
            .build();
        
        httpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e(TAG, "Get feed failed: " + e.getMessage());
                if (callback != null) {
                    callback.onError("Network error: " + e.getMessage());
                }
            }
            
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                try {
                    if (response.isSuccessful() && response.body() != null) {
                        String responseBody = response.body().string();
                        JsonArray jsonArray = gson.fromJson(responseBody, JsonArray.class);
                        
                        List<Hike> hikes = new ArrayList<>();
                        for (int i = 0; i < jsonArray.size(); i++) {
                            JsonObject jsonObject = jsonArray.get(i).getAsJsonObject();
                            Hike hike = gson.fromJson(jsonObject, Hike.class);
                            hikes.add(hike);
                        }
                        
                        if (callback != null) {
                            callback.onSuccess(hikes);
                        }
                    } else {
                        if (callback != null) {
                            callback.onError("Failed to get feed: " + response.code());
                        }
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Error parsing feed: " + e.getMessage());
                    if (callback != null) {
                        callback.onError("Error parsing feed: " + e.getMessage());
                    }
                }
            }
        });
    }
    
    /**
     * Follow a user
     */
    public void followUser(long followerId, long followedId, FollowCallback callback) {
        String url = BASE_URL + "/follows";
        
        JsonObject body = new JsonObject();
        body.addProperty("followerId", followerId);
        body.addProperty("followedId", followedId);
        
        RequestBody requestBody = RequestBody.create(
            body.toString(),
            okhttp3.MediaType.parse("application/json")
        );
        
        Request request = new Request.Builder()
            .url(url)
            .post(requestBody)
            .addHeader("Authorization", "Bearer " + authToken)
            .build();
        
        httpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e(TAG, "Follow user failed: " + e.getMessage());
                if (callback != null) {
                    callback.onError("Network error: " + e.getMessage());
                }
            }
            
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                try {
                    if (response.isSuccessful()) {
                        if (callback != null) {
                            callback.onSuccess("User followed successfully");
                        }
                    } else {
                        if (callback != null) {
                            callback.onError("Failed to follow user: " + response.code());
                        }
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Error following user: " + e.getMessage());
                    if (callback != null) {
                        callback.onError("Error: " + e.getMessage());
                    }
                }
            }
        });
    }
    
    /**
     * Unfollow a user
     */
    public void unfollowUser(long followerId, long followedId, FollowCallback callback) {
        String url = BASE_URL + "/follows";
        
        JsonObject body = new JsonObject();
        body.addProperty("followerId", followerId);
        body.addProperty("followedId", followedId);
        
        RequestBody requestBody = RequestBody.create(
            body.toString(),
            okhttp3.MediaType.parse("application/json")
        );
        
        Request request = new Request.Builder()
            .url(url)
            .delete(requestBody)
            .addHeader("Authorization", "Bearer " + authToken)
            .build();
        
        httpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e(TAG, "Unfollow user failed: " + e.getMessage());
                if (callback != null) {
                    callback.onError("Network error: " + e.getMessage());
                }
            }
            
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                try {
                    if (response.isSuccessful()) {
                        if (callback != null) {
                            callback.onSuccess("User unfollowed successfully");
                        }
                    } else {
                        if (callback != null) {
                            callback.onError("Failed to unfollow user: " + response.code());
                        }
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Error unfollowing user: " + e.getMessage());
                    if (callback != null) {
                        callback.onError("Error: " + e.getMessage());
                    }
                }
            }
        });
    }
    
    /**
     * Check if user follows another user
     */
    public void checkFollowStatus(long followerId, long followedId, CheckFollowCallback callback) {
        String url = BASE_URL + "/follows/check?followerId=" + followerId + "&followedId=" + followedId;
        
        Request request = new Request.Builder()
            .url(url)
            .get()
            .addHeader("Authorization", "Bearer " + authToken)
            .build();
        
        httpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e(TAG, "Check follow status failed: " + e.getMessage());
                if (callback != null) {
                    callback.onError("Network error: " + e.getMessage());
                }
            }
            
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                try {
                    if (response.isSuccessful() && response.body() != null) {
                        String responseBody = response.body().string();
                        JsonObject jsonObject = gson.fromJson(responseBody, JsonObject.class);
                        boolean isFollowing = jsonObject.get("isFollowing").getAsBoolean();
                        
                        if (callback != null) {
                            callback.onSuccess(isFollowing);
                        }
                    } else {
                        if (callback != null) {
                            callback.onError("Failed to check follow status: " + response.code());
                        }
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Error checking follow status: " + e.getMessage());
                    if (callback != null) {
                        callback.onError("Error: " + e.getMessage());
                    }
                }
            }
        });
    }
}
